
const calcularAreaCirculo = require('./area');

const raio = 5;
const area = calcularAreaCirculo(raio);

console.log(`A área do círculo com raio ${raio} é: ${area}`);