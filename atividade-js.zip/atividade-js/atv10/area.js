
function calcularAreaCirculo(raio) {
    return Math.PI * Math.pow(raio, 2);
}


module.exports = calcularAreaCirculo;